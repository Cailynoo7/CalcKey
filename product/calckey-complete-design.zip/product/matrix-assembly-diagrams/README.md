# CalcKey矩阵PCB直观焊装图

适用当前MATRIX A矩阵PCB、20个已确认佳达隆KS-9三脚红轴、Pico 2和GDM0103/HT1621B。该套图对应PCB发布`17123bc08553010640eaa377912e790923ec95a26949b1e102fa73c7f9b2c727`，不能套用到旧手焊行列版。这里没有改动电路、PCB、外壳或固件，也没有烧录、上电或实物测量。

## 图纸

四页A3横向矢量PDF为`calckey-matrix-pcb-assembly.pdf`；每页同时提供SVG和PNG。图纸是装配示意，焊盘中心来自发布版电路记录；器件轮廓、导线与放大框为示意，不可当作1:1开孔、制板或加工模板。

1. `01-component-orientation`：按键面/底面对照，20个轴、20个二极管、4个0805电阻及10个焊线点的位置。
2. `02-j1-j10-to-pico`：真实底面J焊盘顺序、逐线对应表和Pico物理针脚图。
3. `03-lcd-orientation-and-wiring`：GDM0103显示面/背面端子对照、五根独立导线、3V3分支节点和不接端子的绝缘。
4. `04-details-and-unpowered-checks`：二极管黑环与K焊盘放大、R1～R4底面位置放大、焊装顺序和断电检查。

附`soldering-map.csv`（10根矩阵线、5根LCD线及4个不接端子）、`unpowered-check-record.csv`（59项空白记录：4列上拉、20键正反向、15根导线）及`source-checks.json`（来源和输入哈希）。所有实测字段为空、结果为“待测”，不能当作实物验收通过。

实际焊装按`guided-soldering.md`逐步操作：从裸板、0805与二极管，到面板/轴、独立矩阵测量、10根J线、LCD五线，再到绝缘及合盖前检查。每步都有完成条件、20键测点表、异常排查和读数回报格式。已经接到Pico的矩阵不能直接套用独立矩阵的电阻/二极管判据。

## 持板和焊接方向

- 矩阵板两图均屏幕端朝上。底面图已左右镜像：近端焊盘从左到右为J10、J9……J1；20个二极管的黑环K都在左边，接方形pad1，右边pad2为A。不要再次镜像。
- SW1～SW20在按键面安装，面板卡扣承担轴体定位，PCB在下方；仅焊每个轴的两个金属触点，中心塑料柱NPTH孔不焊。轴体方向由塑料柱与两触点的非对称孔位共同确定，不能凭键帽文字猜轴方向。
- R1～R4为10kΩ±1%的0805无极性电阻。底面远端中央，最远一排左R4、右R3，下一排左R2、右R1；分别上拉COL3、COL2、COL1、COL0。
- 第2页的Pico是**元件面朝向读者、USB向上**，用于读针脚；实际装机USB在机身右侧。Pico物理针脚1在左上，40在右上；翻至Pico背面时左右互换。数字为物理针脚号，GP编号另列。其余未用引脚只画位置，不赋予猜测信号名。
- LCD以厂家图纸中的显示上边定位；正面左侧自上而下P1～P6，背面右侧自上而下P1～P6。先识别P1丝印，再对照厂家图；图中端子间距不代表实物比例。

## 接线要点

矩阵：J1～J5依次接GP2～GP6，对应Pico物理4、5、6、7、9；J6～J9依次接GP7～GP10，对应物理10、11、12、14；J10接3V3 OUT/物理36。矩阵没有GND端子，扫描行不能接地。

LCD：P1 /CS→GP11/物理15，P2 /WR→GP1/物理2，P3 DATA→GP0/物理1，P4 VSS→GND/物理38，P5 VDD→3V3 OUT/物理36。P6 /INT、P7 BL+、P8 BL-、P9 Ctrl分别绝缘不接外部线；不要求这些端子在模块内部互相测为OL。

J10与LCD P5共享Pico物理36的3.3V输出节点。两根软线到同一节点，不能桥接相邻Pico针脚，也不能接VBUS、VSYS或5V。线色仅为识别建议，按两端标签核对；交叉无圆点不相连，圆点表示连接。

J1～J10为板上一体SMD铜垫，按当前设计低位直焊10根26AWG绝缘软线，不采购排针或插座。LCD独立5根软线。各约150mm留维护余量，不额外增加直立接头。LCD板背焊点/首段导线突出不超过1.5mm，朝内平铺。固定线皮，避免焊盘承受开盖拉力；底盖缓慢下放约30mm，完全分离仍需断开焊线。

断电记录先在Pico、LCD均未接入矩阵时测被动矩阵；按键按下时红表笔接列、黑表笔接行，应有二极管正向压降，反测应截止。在路读数可能受其他路径影响，有疑问时分离器件复测。接线后逐根查端到端导通和相邻焊点桥接；不能用蜂鸣器对含芯片的整机套用“所有不相关引脚必须OL”。

## 来源及核对范围

- PCB位置、层面、焊盘编号、20条单键支路与4条上拉：来自上述不可变发布包的电路记录，生成脚本逐项断言。
- Pico物理针脚和3V3输出：[Raspberry Pi Pico 2数据表](https://pip.raspberrypi.com/documents/RP-008299-DS)，PDF第5页Figure 2。
- LCD端子定义与显示面方向：[GDM0103模块使用手册](https://www.radiomag.com.de/datasheets/gdm0103_specification.pdf)，PDF第7页外形图、第8页I/O表。
- 现有整机接线记录与固件GPIO检查：20键/20二极管、4个上拉及LCD信号一致。
- 底面朝向、黑环和J焊盘顺序与当前发布的底面Gerber图相符。实时PCB渲染因运行环境权限错误未生成新图，此次使用已有发布图核对，不影响基于发布数据的绘图。
- 四页PDF已逐页目视检查。实物焊接、断电读数及上电功能均仍待实际制作；本次不烧录。

## 获取和再生成

右键Product标签→Show in Finder，找到本套矩阵PCB焊装图，可查看PDF、单页SVG/PNG和记录表。制板仍使用matrix标签→Fabrication files→PCB manufacturing package，不能把焊装示意SVG交给工厂当Gerber。

生成器`generate.py`需要reportlab 4.4.3及中文TrueType字体，默认macOS Arial Unicode；可用`CALCKEY_DIAGRAM_FONT`指定。工作区已有依赖时执行：

```sh
PYTHONPATH=.work/wiring-diagram-tools python3 product/matrix-assembly-diagrams/generate.py
```

PNG是最终PDF的页面渲染件；通过PDF渲染工具重新生成，不从SVG屏幕截图取代。生成器仅写本套文档，不写电路、制板包、接线源或固件。
