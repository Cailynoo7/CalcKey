#!/usr/bin/env python3
"""Check the implemented GPIO mapping against the project-owned wiring file."""
import json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
wiring = json.loads((ROOT / 'design/enclosure/source/wiring.json').read_text())
connections = wiring['connections']
def linked(part, pin):
    return [c['from']['pin'] for c in connections
            if c['from']['part'] == 'MCU' and c['to'] == {'part': part, 'pin': pin}]
assert linked('OLED', 'SDA') == ['GP0']
assert linked('OLED', 'SCL') == ['GP1']
for row in range(5):
    for col in range(4):
        n = row * 4 + col + 1
        assert linked('SW%02d' % n, '1') == ['GP%d' % (7 + col)]
        diode = [c for c in connections if c['from'] == {'part': 'D%02d' % n, 'pin': 'K'}]
        assert len(diode) == 1 and diode[0]['to'] == {'part': 'MCU', 'pin': 'GP%d' % (2 + row)}
assert any(p.get('platform') == 'raspberrypi/pico-2' for p in wiring['parts'])
print('PASS OLED and all 20 row/column/diode mappings match wiring.json')
