#include "oled.hpp"
#include "board_config.hpp"
#include "hardware/i2c.h"
#include "hardware/gpio.h"
#include "pico/time.h"
#include <algorithm>
#include <cctype>
#include <cstring>

namespace calckey {
namespace {
// Original compact 3x5 bitmap alphabet, packed as five rows of three bits.
uint16_t glyph(char c) {
    switch(c) {
    case '0':return 0x7b6f; case '1':return 0x2492; case '2':return 0x73e7;
    case '3':return 0x73cf; case '4':return 0x5bc9; case '5':return 0x79cf;
    case '6':return 0x79ef; case '7':return 0x7249; case '8':return 0x7bef;
    case '9':return 0x7bcf;
    case 'A':return 0x2bed; case 'B':return 0x6bae; case 'C':return 0x7927;
    case 'D':return 0x6b6e; case 'E':return 0x79e7; case 'F':return 0x79e4;
    case 'G':return 0x796f; case 'H':return 0x5bed; case 'I':return 0x7497;
    case 'J':return 0x124f; case 'K':return 0x5bad; case 'L':return 0x4927;
    case 'M':return 0x5fed; case 'N':return 0x5f7d; case 'O':return 0x7b6f;
    case 'P':return 0x7be4; case 'Q':return 0x7b7b; case 'R':return 0x6bad;
    case 'S':return 0x79cf; case 'T':return 0x7492; case 'U':return 0x5b6f;
    case 'V':return 0x5b6a; case 'W':return 0x5bfd; case 'X':return 0x5aad;
    case 'Y':return 0x5a92; case 'Z':return 0x72a7;
    case '+':return 0x05d0; case '-':return 0x01c0; case '*':return 0x15d4;
    case '/':return 0x12a4; case '=':return 0x0e38; case '.':return 0x0002;
    case ':':return 0x0410; default:return 0;
    }
}
}
void Oled::init() {
    i2c_init(i2c0,i2c_baud);
    gpio_set_function(oled_sda,GPIO_FUNC_I2C); gpio_set_function(oled_scl,GPIO_FUNC_I2C);
    gpio_disable_pulls(oled_sda); gpio_disable_pulls(oled_scl); // vendor board has pullups
}
bool Oled::write(const uint8_t* p,unsigned size) {
    if(i2c_write_timeout_us(i2c0,address_,p,size,false,1500)==int(size)) return true;
    online_=false; transfer_=false; initializing_=false; shown_.clear();
    retry_at_=uint32_t(time_us_64()/1000)+1000; return false;
}
bool Oled::command(uint8_t c) { uint8_t b[]={0,c}; return write(b,2); }
bool Oled::connect() {
    // Same SSD1306-compatible command family used by Seeed's SSD1315 U8g2 example.
    // Keep each command and its parameter in one transaction.
    static constexpr uint8_t init[][3]={
        {0xae,0,0},{0xd5,0x80,1},{0xa8,0x3f,1},{0xd3,0,1},{0x40,0,0},
        {0x8d,0x14,1},{0x20,0x02,1},{0xa1,0,0},{0xc8,0,0},{0xda,0x12,1},
        {0x81,0x7f,1},{0xd9,0xf1,1},{0xdb,0x40,1},{0x2e,0,0},{0xa4,0,0},{0xa6,0,0}
    };
    // Probe only the two documented 7-bit address variants; one bounded transaction per retry.
    if(!initializing_) {
        if(!command(0xae)) { address_=address_==0x3c?0x3d:0x3c; return false; }
        initializing_=true; init_offset_=0; return true;
    }
    uint8_t b[3]={0,init[init_offset_][0],init[init_offset_][1]};
    if(!write(b,init[init_offset_][2]?3:2)) return false;
    ++init_offset_;
    if(init_offset_==sizeof(init)/sizeof(init[0])) { online_=true; awake_=false; initializing_=false; shown_.clear(); }
    return true;
}
void Oled::text(int x,int y,const std::string& s,int scale) {
    for(char c:s) {
        uint16_t bits=glyph(char(std::toupper(static_cast<unsigned char>(c))));
        for(int r=0;r<5;++r) for(int col=0;col<3;++col) if(bits&(1u<<(14-r*3-col))) {
            for(int dy=0;dy<scale;++dy) for(int dx=0;dx<scale;++dx) {
                int xx=x+col*scale+dx,yy=y+r*scale+dy;
                if(xx>=0&&xx<128&&yy>=0&&yy<64) pixels_[(yy/8)*128+xx]|=1u<<(yy%8);
            }
        }
        x+=4*scale;
    }
}
void Oled::render(const std::string& title,const std::string& value,const std::string& footer) {
    pixels_.fill(0); text(0,0,title,1); text(0,18,value,value.size()<=16?2:1); text(0,50,footer,1);
    for(unsigned x=0;x<128;++x) pixels_[128+x]|=0x04;
    page_=column_=0; page_command_=true; transfer_=true;
}
void Oled::task(uint32_t now,const Application& app,bool numlock) {
    if(!online_) {
        if(app.suspended()) return;
        if(int32_t(now-retry_at_)<0) return;
        connect();
        return;
    }
    if(app.suspended()) {
        if(awake_ && command(0xae)) awake_=false;
        return;
    }
    std::string title=app.mode()==Mode::calculator?"CALC":"KEYPAD";
    title+=app.mounted()?"  USB":"  POWER";
    std::string value=app.mode()==Mode::calculator?app.calculator.text():(numlock?"NUM LOCK ON":"NUM LOCK OFF");
    std::string footer=app.mode()==Mode::calculator?"OP "+std::string(1,app.calculator.operation()?app.calculator.operation():' '):"MODE: LOCAL CALC";
    std::string signature=title+'|'+value+'|'+footer;
    // Finish the current frame before replacing it; continuously edited input cannot starve refresh.
    if(!transfer_ && shown_!=signature) { render(title,value,footer); shown_=signature; }
    if(transfer_) {
        if(page_command_) {
            uint8_t b[]={0,uint8_t(0xb0+page_),0x00,0x10};
            if(write(b,4)) page_command_=false;
        } else {
            uint8_t b[9]={0x40}; std::memcpy(b+1,pixels_.data()+page_*128+column_,8);
            if(!write(b,9)) return;
            column_+=8;
            if(column_==128) { column_=0; ++page_; page_command_=true; if(page_==8) transfer_=false; }
        }
    } else if(!awake_ && command(0xaf)) awake_=true; // enable only after valid RAM frame
}
}
