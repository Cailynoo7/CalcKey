#pragma once
#include <array>
#include <cstdint>
namespace calckey {
// Pin evidence: enclosure wiring.json; Pico RP-008299-DS p5; Seeed J1 schematic.
inline constexpr std::array<unsigned,5> row_pins={2,3,4,5,6};
inline constexpr std::array<unsigned,4> column_pins={7,8,9,10};
inline constexpr unsigned oled_sda=0, oled_scl=1;
inline constexpr uint32_t matrix_interval_us=2000, i2c_baud=100000;
inline constexpr unsigned usb_vid=0xcafe, usb_pid=0x2350; // prototype IDs
}
