#pragma once
#include "core.hpp"
#include <array>
namespace calckey {
class Oled {
public:
    void init();
    void task(uint32_t now_ms,const Application&,bool numlock);
    bool online() const { return online_; }
private:
    std::array<uint8_t,1024> pixels_{};
    bool online_=false, awake_=true, page_command_=true, transfer_=false, initializing_=false;
    unsigned init_offset_=0;
    uint8_t address_=0x3c, page_=0, column_=0;
    uint32_t retry_at_=0;
    std::string shown_;
    bool write(const uint8_t*,unsigned);
    bool command(uint8_t);
    bool connect();
    void render(const std::string&,const std::string&,const std::string&);
    void text(int,int,const std::string&,int);
};
}
