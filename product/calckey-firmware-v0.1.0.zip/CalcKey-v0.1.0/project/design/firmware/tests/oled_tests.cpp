#include "oled.hpp"
#include "hardware/i2c.h"
#include <cstdlib>
#include <iostream>
#include <vector>
static i2c_inst_t bus;
i2c_inst_t* i2c0=&bus;
static uint64_t clock_us=0;
static bool nack=false;
static unsigned calls=0,checks=0;
static std::vector<std::vector<uint8_t>> packets;
unsigned i2c_init(i2c_inst_t*,unsigned baud) { return baud; }
uint64_t time_us_64() { return clock_us; }
int i2c_write_timeout_us(i2c_inst_t*,uint8_t,const uint8_t* p,size_t n,bool,unsigned timeout) {
    ++calls; if(n>9||timeout>1500) std::abort();
    if(nack) return -1;
    packets.emplace_back(p,p+n); return int(n);
}
static void check(bool ok,const char* label) { ++checks; if(!ok) { std::cerr<<label<<'\n'; std::exit(1); } }
int main() {
    calckey::Application app; app.sample(0,0,0);
    calckey::Oled oled; oled.init();
    for(unsigned i=0;i<180;++i) {
        unsigned before=calls; clock_us=i*2000; oled.task(i*2,app,false);
        check(calls-before<=1,"one bounded bus transaction per task");
    }
    check(oled.online(),"OLED initialized");
    bool enabled=false; unsigned data_packets=0;
    for(const auto& p:packets) { if(p[0]==0x40) ++data_packets; if(p==std::vector<uint8_t>{0,0xaf}) enabled=true; }
    check(enabled&&data_packets==128,"full 1024-byte frame then screen on");
    app.mount(); app.suspend(); oled.task(400,app,false);
    check(packets.back()==std::vector<uint8_t>{0,0xae},"suspend screen off");
    unsigned before=calls; oled.task(402,app,false); check(calls==before,"no repeated suspend writes");
    app.resume(); nack=true; clock_us=500000; oled.task(500,app,false);
    check(!oled.online(),"NACK detected");
    before=calls; clock_us=600000; oled.task(600,app,false);check(calls==before,"recovery backoff");
    nack=false;clock_us=1500000;oled.task(1500,app,false);check(calls==before+1,"recovery resumes");
    std::cout<<"PASS "<<checks<<" OLED transport assertions\n";
}
