#pragma once
#include <cstddef>
#include <cstdint>
struct i2c_inst_t {};
extern i2c_inst_t* i2c0;
unsigned i2c_init(i2c_inst_t*,unsigned);
int i2c_write_timeout_us(i2c_inst_t*,uint8_t,const uint8_t*,size_t,bool,unsigned);
