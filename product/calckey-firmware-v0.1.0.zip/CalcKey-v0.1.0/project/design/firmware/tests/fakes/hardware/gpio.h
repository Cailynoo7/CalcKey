#pragma once
#define GPIO_FUNC_I2C 3
inline void gpio_set_function(unsigned,unsigned) {}
inline void gpio_disable_pulls(unsigned) {}
