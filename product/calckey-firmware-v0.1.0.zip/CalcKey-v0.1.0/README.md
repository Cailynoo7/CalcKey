# CalcKey Pico 2 固件 v0.1.0

适用本项目的 Raspberry Pi Pico 2、5行4列手焊二极管矩阵和 Grove SSD1315 128×64 OLED。固件使用 Pico SDK 2.2.0、TinyUSB 0.18.0、Arm GNU Toolchain 14.2.Rel1；这些是本次编译固定的版本，不要求追随开发分支。交付 UF2、ELF、BIN、源代码、测试程序、依赖锁定记录和编译验证记录。编译与桌面测试不等于实机验收，尚未连接真实键盘验证。

## GPIO 与接线

沿用 `design/enclosure/source/wiring.json`，不改变已选硬件。`check_wiring.py`逐键核对20个开关、行、列和二极管阴极，以及OLED接口。

| 信号 | GPIO | 物理引脚 |
| --- | --- | --- |
| OLED SDA / SCL | GP0 / GP1，I²C0，100kHz | 1 / 2 |
| R0～R4 | GP2、GP3、GP4、GP5、GP6 | 4、5、6、7、9 |
| C0～C3 | GP7、GP8、GP9、GP10 | 10、11、12、14 |
| OLED电源 / 地 | 3V3 / GND | 36 / 38 |
| 主机或充电器 | Pico原生Micro-B接口 | 板载USB |

列经已选10k电阻上拉到3.3V。每键从列经开关到1N4148阳极，阴极色环接行。扫描时只把当前行拉低，其他行高阻；GPIO不启用内部上拉。完整矩阵目标每2ms扫描一次，每键稳定5ms后确认状态。主核栈预留4KiB，编译生成逐函数栈使用记录；尚未实测最坏情况栈峰值。OLED断开、NACK或总线超时时仍运行矩阵和USB任务。

## 模式与按键

| NumLock | / | * | Backspace |
| --- | --- | --- | --- |
| 7 | 8 | 9 | - |
| 4 | 5 | 6 | + |
| 1 | 2 | 3 | Enter / = |
| Mode | 0 | . | AC |

- 上电先为本地计算器；只接充电器不会因为USB有电而进入键盘模式。收到USB配置完成事件才自动进入键盘模式。
- 已连接主机时Mode在键盘和本地计算之间切换。只接充电器时Mode保持计算器。计算器模式不发送计算按键给电脑。
- 模式切换、USB重新配置、传输失败或恢复时，优先排队一个全释放报告。必须等所有实体键和去抖状态均释放，才能接受新一轮输入；切换期间按住的键不会突然输入到电脑或计算器。
- USB挂起保持模式，关闭OLED、停止行驱动和按键操作；恢复后先释放报告并等待所有键抬起。不启用远程唤醒。若主机移除只表现为挂起而没有断开事件，不通过超时猜测充电器；重新上电会重新判别。USB挂起电流和协议合规尚未实测。
- 键盘采用标准Boot Keyboard报告和数字小键盘usage，6键无冲；超过6个主机键报告ErrorRollOver。NumLock由主机控制，屏幕显示主机返回的NumLock灯状态。各操作系统/应用如何解释NumLock关闭和小数键，仍以实测为准。
- Mode不映射主机键；AC始终只清除本地计算器，在键盘模式也不发送快捷键。
- 计算器每次按下只输入一次；Backspace按住500ms后每80ms重复，普通数字不自动重复。键盘长按重复由电脑控制。
- HID报告FIFO保留USB忙时短按的按下/抬起顺序；队列溢出时以全释放并等待抬键恢复，避免卡键。

## 计算规则

十进制系数与指数运算，不用二进制浮点近似十进制小数。每步计算保留12位有效数字，采用十进制四舍五入，恰好一半时远离零；`0.1+0.2`显示`0.3`。先后逐步计算，不处理表达式优先级：`2+3*4=`为`20`。

支持输入小数、退格、AC、负数结果和负操作数：初始按减号可输入负数，待输入第二操作数时按减号也可输入负数，例如`2*-3=`。重复等号重复上一操作。连续操作符替换待执行操作（减号在等待操作数时用作负号）。结果后输入数字开始新数，操作符则接着结果计算。

数值范围为十进制数量级-99～+99，超过该范围显示OVERFLOW，除零显示DIV BY ZERO；AC或重新输入数字可恢复。最多12位有效输入数字，输入文本最多18字符。需要时使用科学计数法，屏幕不会截断符号或指数。没有计算历史、非易失存储或科学函数。

## OLED

沿用Seeed官方对SSD1315使用SSD1306兼容控制命令的方式；默认0x3C，未应答时轮流尝试0x3D，每次失败后退避1秒。地址按7位表示，不使用原理图中含方向位的0x78写地址。

自有3×5字模显示模式、USB状态、操作符、12位结果和错误提示。短结果放大2倍；长结果/科学计数法用紧凑字号。没有复制第三方字库。每次任务最多一次I²C传输、最长9字节、超时1500µs；初始化命令与参数同包发送。1024字节帧分段发送，第一帧写完才开屏；输入不断变化也会先完成当前帧，避免刷新饥饿。

显示方向默认A1/C8，实际玻璃朝向、对比度、读取角度和刷新观感需实机检查。没有OLED时USB键盘仍可工作，本地计算仍计算但无法看到结果。

## 构建与验证

项目根目录执行：

```sh
python3 design/firmware/bootstrap.py
python3 design/firmware/build.py
```

bootstrap只把固定版本工具下载到项目`.work/firmware-tools`，校验锁定SHA256，不修改系统工具。该自动下载脚本针对本次macOS arm64机器。其他系统自行安装固定版本，设置`PICO_SDK_PATH`、`PICO_TINYUSB_PATH`、`PICO_TOOLCHAIN_PATH`、`CALCKEY_PICOTOOL_DIR`，需要时设置`CALCKEY_CMAKE`、`CALCKEY_NINJA`、`CXX_HOST`。桌面测试需要支持AddressSanitizer/UndefinedBehaviorSanitizer的Clang。

构建脚本先检查接线，运行计算器/模式/去抖测试、OLED传输模拟及2500组Python decimal对照，再交叉编译Pico 2，验证官方picotool识别的目标芯片/架构及UF2结构，最后生成`release/`交付件和产品目录中的固件压缩包。测试与命令结果、源码和接线哈希、依赖版本、UF2/ELF/BIN哈希保存在`verification.json`。不生成任何自称实机已通过的报告。

## 烧录与实机验收

1. 先不合壳，按接线表装好矩阵和OLED，检查二极管方向、3.3V与地。
2. 按住Pico 2板上的BOOTSEL再插USB到电脑，看到RP2350磁盘后松开。将交付的Pico 2版本UF2复制到该磁盘，板会重启；这会替换板上原固件。
3. 确认电脑识别CalcKey Dual Mode，逐键核对20键；主机键只有18个，Mode及AC不向电脑发键。核对NumLock和小数点在目标应用中的表现。
4. 连接电脑时按Mode，确认本地计算不向编辑器发键；按住数字切模式，确认没有遗留重复输入，抬键后才恢复新输入。
5. 断电改接只有5V的充电器，确认默认CALC，执行12+34=46、7-10=-3、1.5*2=3、8/4=2、0.1+0.2=0.3及除零/AC恢复。
6. 核对小数、负数、反复等号、Backspace长按、OLED拔除、主机睡眠/唤醒、插拔、至少7键同时按下；测试USB挂起电流、连续运行稳定性及所有目标操作系统。

## 依据与许可

- [Pico SDK 2.2.0构建说明](https://github.com/raspberrypi/pico-sdk/tree/2.2.0)，板型pico2、ARM Cortex-M33、SDK原生UF2生成。
- [TinyUSB 0.18.0设备HID示例与API](https://github.com/hathach/tinyusb/tree/0.18.0/examples/device/hid_composite)，配置、挂起/恢复、全释放键盘报告和NumLock输出报告。
- [Seeed SSD1315官方示例](https://wiki.seeedstudio.com/Grove-OLED-Display-0.96-SSD1315/)，128×64 I²C、使用SSD1306兼容初始化。
- [Pico 2官方引脚资料](https://pip.raspberrypi.com/documents/RP-008299-DS)，接线逐项引用已记录在wiring.json。
- [Raspberry Pi官方BOOTSEL操作](https://github.com/raspberrypi/documentation/blob/master/documentation/asciidoc/microcontrollers/micropython/drag-and-drop.adoc)，Pico 2磁盘名RP2350。

USB VID 0xCAFE/PID 0x2350为样机测试标识，未声明商业分配。SDK为BSD-3-Clause，TinyUSB为MIT；固件交付包保留其许可。当前项目自身尚未设置对外发布许可证，此次只做本地交付，没有发布或提交Git。
